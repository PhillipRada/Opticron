# Opticron
Within the provided Git repository, the website's frontend components are available, showcasing my proficiency in seamlessly integrating SQL databases with frontend interfaces. I've effectively imported and organized data into the SQL database to demonstrate my adeptness in utilizing SQL and Front-end. I can change the table and new tables to SQL database.





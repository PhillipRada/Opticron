﻿
namespace Test1.DBContext
{
    public class CardProducts
    {
        public int CardId { get; set; }
        public string? Title { get; set; }
        public string? ImagePath { get; set; }
        public string? Description { get; set; }
        public string? ButtonText { get; set; }
    }
}

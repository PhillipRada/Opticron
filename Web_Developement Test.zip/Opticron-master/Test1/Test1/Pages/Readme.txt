Within the provided Git repository, the website's frontend components are available, showcasing my proficiency in seamlessly integrating SQL databases with frontend interfaces. I've effectively imported and organized data into the SQL database to demonstrate my adeptness in utilizing SQL. From the website I can manage the tables and set up new tables for other data.




